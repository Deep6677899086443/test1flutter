import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(HangmanApp());
}

class HangmanApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HangmanGame(),
    );
  }
}

class HangmanGame extends StatefulWidget {
  @override
  _HangmanGameState createState() => _HangmanGameState();
}

class _HangmanGameState extends State<HangmanGame> {
  final List<String> words = ["FLUTTER", "HANGMAN", "PROGRAM", "MOBILE", "DEVELOP"];
  late String selectedWord;
  late List<String> guessedLetters;
  int wrongGuesses = 0;
  final int maxWrongGuesses = 6;

  @override
  void initState() {
    super.initState();
    _resetGame();
  }

  void _resetGame() {
    setState(() {
      selectedWord = words[Random().nextInt(words.length)];
      guessedLetters = [];
      wrongGuesses = 0;
    });
  }

  void _guessLetter(String letter) {
    if (guessedLetters.contains(letter)) return;
    setState(() {
      guessedLetters.add(letter);
      if (!selectedWord.contains(letter)) {
        wrongGuesses++;
      }
    });
  }

  String _displayWord() {
    return selectedWord.split('').map((char) => guessedLetters.contains(char) ? char : '_').join(' ');
  }

  @override
  Widget build(BuildContext context) {
    bool hasWon = selectedWord.split('').every((char) => guessedLetters.contains(char));
    bool hasLost = wrongGuesses >= maxWrongGuesses;
    
    return Scaffold(
      appBar: AppBar(title: Text("Hangman Game")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Word: ${_displayWord()}", style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            Text("Wrong Guesses: $wrongGuesses/$maxWrongGuesses", style: TextStyle(fontSize: 20)),
            SizedBox(height: 20),
            Wrap(
              spacing: 10,
              children: "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split('').map((letter) {
                return ElevatedButton(
                  onPressed: (hasWon || hasLost) ? null : () => _guessLetter(letter),
                  child: Text(letter),
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            if (hasWon) Text("You WON!", style: TextStyle(fontSize: 30, color: Colors.green)),
            if (hasLost) Text("You LOST! The word was $selectedWord", style: TextStyle(fontSize: 30, color: Colors.red)),
            if (hasWon || hasLost)
              ElevatedButton(onPressed: _resetGame, child: Text("Play Again"))
          ],
        ),
      ),
    );
  }
}
